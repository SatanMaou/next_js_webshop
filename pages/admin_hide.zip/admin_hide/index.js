import React from "react";
import Router from "./routes";

export default function Index() {
  React.useEffect(() => {
    Router.push("./adminItem/dashboard.js");
  });

  return <div />;
}
